package org.eclipse.jconqurr.annotations.processors;

import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.element.TypeElement;

public class DivideAndConquerProcessor extends AbstractProcessor {
	public boolean process(Set<? extends TypeElement> arg0,
			RoundEnvironment arg1) {
		// TODO Auto-generated method stub
		return false;
	}
}
