package org.eclipse.jconqurr.directives;

public class Directives {
public static final void startTask(){};
public static final void endTask(){};
public static final void forLoop(){};
public static final void barrier(){};

}
