package org.eclipse.jconqurr.core.task;

import java.util.ArrayList;
import java.util.List;
 

import org.eclipse.jconqurr.core.ast.visitors.LineCommentVisitor;
import org.eclipse.jconqurr.core.ast.visitors.SimpleNameVisitor;
import org.eclipse.jconqurr.core.ast.visitors.VariableDeclarationVisitor;
import org.eclipse.jdt.core.dom.IExtendedModifier;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.Statement;

public class TaskMethod implements ITaskMethod {
	private MethodDeclaration method;
	private List<String> tasks = new ArrayList();
	private String returnType;
	private String modifier;
	private String shedulerMethod;
	private List<String> codeAfterBarrier = new ArrayList();
	private static int barrierCounter = 1;
	private static int taskCounter = 1;
	private static int taskNo = 1;

	private String sheduleTasks(List<String> tasks,
			List<String> codeAfterBarrier) {
		/*
		 * String exec =
		 * "static ExecutorService exec = Executors.newCachedThreadPool();" +
		 * "\n";
		 */
		String sheduleTasksMethod = "\n" + shedulerMethod + "(){" + "try{"
				+ "\n" + "Future<?>[] future = (Future<?>[]) new Future["
				+ tasks.size() + "];" + "\n";
		String futureSubmit = "";
		String cyclicBarrier = "CyclicBarrier barrier = new CyclicBarrier("
				+ tasks.size() + "," + "new barrier" + taskCounter + "()"
				+ ");";
		for (int i = 0; i < tasks.size(); i++) {
			futureSubmit = futureSubmit + "future[" + i + "]=exec.submit(new"
					+ " task" + taskNo + "(barrier));" + "\n";
			taskNo++;
		}
		String futureGet = "for(int i=0;i<" + tasks.size() + ";i++)" + "\n"
				+ "future[i].get();" + "\n" + "}" + "\n"
				+ "catch (Exception e) {e.printStackTrace();}}";
		return sheduleTasksMethod + cyclicBarrier + futureSubmit + futureGet;
	}

	public String getModifiedMethod() {
		String taskCode = "";
		String barrierCode = "";
		int i = 1;
		int j = 0;
		for (String s : tasks) {
			taskCode = taskCode + taskRunnerCode("task" + taskCounter, s);
			taskCounter++;
		}
		for (String s : codeAfterBarrier) {
			barrierCode = barrierCode
					+ codeAfterBarrier("barrier" + taskCounter, s);
			barrierCounter++;
		}
		return sheduleTasks(tasks, codeAfterBarrier) + "\n" + taskCode
				+ barrierCode;
	}

	public List<String> getTasks() {
		int directiveStart = -1;
		List<Statement> stmts = method.getBody().statements();
		VariableDeclarationVisitor variableDeclarationVisitor = new VariableDeclarationVisitor();
		
		method.accept(variableDeclarationVisitor);
		variableDeclarationVisitor.getVariablesDeclaraions();
		List<Integer> taskStartPositions = new ArrayList<Integer>();
		List<Integer> taskEndPositions = new ArrayList<Integer>();
		/*SimpleNameVisitor simpleNameVisitor=new SimpleNameVisitor();
		method.getBody().accept(simpleNameVisitor);*/
		List<Integer> barrierPositions = new ArrayList<Integer>();
		for (Statement s : stmts) {
			if (s.toString().startsWith("Directives.startTask();")) {
				directiveStart = stmts.indexOf(s);
				taskStartPositions.add(stmts.indexOf(s));
			}
			if (s.toString().startsWith("Directives.endTask();")) {
				// directiveStart = stmts.indexOf(s);
				taskEndPositions.add(stmts.indexOf(s));
			}
			if (s.toString().startsWith("Directives.barrier();")) {
				// directiveStart = stmts.indexOf(s);
				barrierPositions.add(stmts.indexOf(s));
			}
		}
		if (taskStartPositions.size() > 0) {
			List<Statement> subStatmentBeforeTask = stmts.subList(0,
					(taskEndPositions.get(0)));
			for (int m = 0; m < taskStartPositions.size(); m++) {
				String task = "";
				List<Statement> subStatement;

				// if (m + 1 < taskStartPositions.size()) {
				subStatement = stmts.subList((taskStartPositions.get(m) + 1),
						(taskEndPositions.get(m)));
				/*
				 * } else { subStatement =
				 * stmts.subList((taskStartPositions.get(m) + 1), stmts
				 * .size()); }
				 */
				if (subStatement.size() > 0) {
					for (Statement s : subStatement) {
						task = task + s.toString();
					}
					tasks.add(task);
				}

			}

			if (barrierPositions.size() > 0) {
				String rest = "";
				List<Statement> subStatement = stmts.subList((barrierPositions
						.get(0) + 1), stmts.size());
				for (Statement s : subStatement) {
					rest = rest + s.toString();
				}
				codeAfterBarrier.add(rest);
			}
		}
		return null;
	}

	public void setMethod(MethodDeclaration method) {
		this.method = method;
		// TODO Auto-generated method stub

	}

	private String taskRunnerCode(String task, String taskBody) {
		String barrierCaller = "try {" + "\n" + "barrier.await();" + "\n" + "}"
				+ "\n" + " catch (InterruptedException e) {" + "\n"
				+ "// TODO Auto-generated catch block" + "\n"
				+ "e.printStackTrace();" + "\n" + "}" + "\n"
				+ " catch (BrokenBarrierException e) {" + "\n"
				+ "e.printStackTrace();" + "\n" + "}";
		String taskRunnerCode = "\n" + "public class " + task
				+ " implements Runnable{" + "\n" + "CyclicBarrier barrier;"
				+ "\n" + task + "(CyclicBarrier barrier){" + "\n"
				+ "this.barrier = barrier;" + "\n" + "}"
				+ "public void run() {" + taskBody + barrierCaller + "}}";

		return taskRunnerCode;
	}

	private String codeAfterBarrier(String barrier, String barrierBody) {
		String barrierRunnerCode = "\n" + "public class " + barrier
				+ " implements Runnable{" + "\n" + "public void run() {"
				+ barrierBody + "}}";
		return barrierRunnerCode;
	}

	public void init() {
		// TODO Auto-generated method stub
		// System.out.println("Simple Method Name"+method.getName());
		// System.out.println(method.modifiers().toString());
		returnType = method.getReturnType2().toString();
		LineCommentVisitor visitor = new LineCommentVisitor();
		method.accept(visitor);
		visitor.getComments();
		modifier = "";
		List<IExtendedModifier> modifiers = method.modifiers();
		for (IExtendedModifier a : modifiers) {
			if (a.isModifier()) {
				// System.out.println(((Modifier)
				// a).toString());
				modifier = modifier + " " + ((Modifier) a).toString();
			}
		}
		shedulerMethod = modifier + " " + returnType + " "
				+ method.getName().toString();
		getTasks();

	}

}
