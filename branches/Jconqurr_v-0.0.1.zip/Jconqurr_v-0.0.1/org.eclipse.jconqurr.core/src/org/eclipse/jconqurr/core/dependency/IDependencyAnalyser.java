package org.eclipse.jconqurr.core.dependency;

import org.eclipse.jdt.core.dom.MethodDeclaration;

public interface IDependencyAnalyser {
public void filterStatements(MethodDeclaration method);
}
